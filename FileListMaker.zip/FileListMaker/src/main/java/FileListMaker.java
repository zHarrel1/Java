import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.file.Path;
import javax.swing.JFileChooser;
import java.util.ArrayList;
import java.util.Scanner;


public class FileListMaker 
{

    static ArrayList<String> list = new ArrayList<>();
   
   
    public static void main(String[] args) throws FileNotFoundException, IOException 
    {
        Scanner sc = new Scanner(System.in);
        
        final String menu = "A - add  D - delete  V - view  O - open  S - save  C - clear  Q - quit";
        boolean done = false;
        String cmd = "";
        String item = "";
        int choice;
        int size;
        int index = 0;
        boolean save = false;
        boolean cont;
        boolean quit = false;
        boolean newFile = true;
        JFileChooser chooser = new JFileChooser();
        Scanner inFile;
        String line;
        Path target = new File(System.getProperty("user.dir")).toPath();
        target = target.resolve("src");
        chooser.setCurrentDirectory(target.toFile());
        
        
        do
        {
            displayList();
            
            cmd = SafeInput.getRegExString(sc, menu, "[AaDdVvQqSsOoCc]");
            cmd = cmd.toUpperCase();
            
            switch(cmd)
            {
                case "A":
                    item = SafeInput.getNonZeroLenString(sc, "Enter a list item: ");
                    list.add(item);
                    break;
                case "D":
                    size = list.size();
                    if(size != 0)
                    {
                        choice = SafeInput.getRangedInt(sc, "Which item do you want to delete: ", 1, size);
                        list.remove(choice - 1);
                        break;
                    }
                    else
                    {
                        System.out.println("No items in list");
                        continue;
                    }                             
                case "V":
                    displayList();
                    continue;
                case "C":
                    list.clear();
                    break;
                case "O":
                    if(newFile)
                    {
                        save = SafeInput.getYNConfirm(sc, "Do you want to save the current list? (Y or N): ");
                        if(save)
                        {
                            
                            FileOutputStream fileOut = new FileOutputStream("listdata" + index + ".txt");
                            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fileOut));

                            for (String text : list)
                               {
                                bw.write(text);
                                bw.newLine();
                               }
                                bw.close();

                            index += 1;
                            
                        }
                    }
                        
                        if(chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
                        {
                            target = chooser.getSelectedFile().toPath();

                            inFile = new Scanner(target);
                            
                            list.clear();

                            while(inFile.hasNextLine())
                            {
                                list.add(inFile.nextLine());
                            }

                            inFile.close();
                            newFile = false;
                        }
                        else
                        {
                            System.out.println("No file selected");
                            System.exit(0);
                        }
                    break;

                case "S":
                    if(newFile)
                    {
                        FileOutputStream fileOut = new FileOutputStream("listdata" + index + ".txt");
                        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fileOut));
                        
                        for (String text : list)
                        {
                          bw.write(text);
                          bw.newLine();
                        }
                        bw.close();
                       
                        index += 1;
                        break;
                    }
                    else
                    {
                        FileOutputStream fileOut = new FileOutputStream(chooser.getSelectedFile().getName());
                        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fileOut));

                        for (String text : list)
                        {
                          bw.write(text);
                          bw.newLine();
                        }
                        bw.close(); 
                        
                        index += 1;
                        break;
                    }
                    
                case "Q":
                    quit = SafeInput.getYNConfirm(sc, "Are you sure? (Y or N): ");
                    if(quit)
                    {
                        save = SafeInput.getYNConfirm(sc, "Do you want to save the current list? (Y or N): ");
                        if(save)
                        {
                            if(newFile)
                            {
                                FileOutputStream fileOut = new FileOutputStream("listdata" + index + ".txt");
                                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fileOut));

                                for (String text : list)
                                {
                                  bw.write(text);
                                  bw.newLine();
                                }
                                bw.close();

                                index += 1;
                                
                                System.exit(0);
                                
                            }
                            else
                            {
                                FileOutputStream fileOut = new FileOutputStream(chooser.getSelectedFile().getName());
                                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fileOut));

                                for (String text : list)
                                {
                                  bw.write(text);
                                  bw.newLine();
                                }
                                bw.close(); 

                                index += 1;
                                
                                System.exit(0);
                            }
                        }
                        else
                        {
                            System.exit(0);
                        }
                               
                    }
                    else
                    {
                        sc.nextLine();
                        continue;
                    }   
            }
                              
            cont = SafeInput.getYNConfirm(sc, "Continue editing list? (Y or N): ");
            
            if(!cont)
            {
                done = true;
            }
            
            sc.nextLine();
                        
        }while(!done);
        
        
    }

    private static void displayList() 
    {
        System.out.println("");
        System.out.println("---------------------");
        
        if(list.size() != 0)
        {
            for(int i=0; i<list.size(); i++)
                {
                    System.out.println(i+1 + ": " + list.get(i));
                }
        }
        else
        {
            System.out.println("--- list is empty ---");
        }
                
        System.out.println("---------------------");
        System.out.println("");

    }
    
}
