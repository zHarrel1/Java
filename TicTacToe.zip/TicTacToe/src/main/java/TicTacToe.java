
import java.util.Scanner;


public class TicTacToe 
{

    private static final int ROW = 3;
    private static final int COL = 3;
    private static String board[][] = new String[ROW][COL];
    
    
    
    public static void main(String[] args)
    {
       String player = "X";
       int playerRow;
       int playerCol;
       int moves = 0;
       boolean play = true;
       boolean valid = true;
      
       Scanner sc = new Scanner(System.in);
       
       clearBoard();
       
       do
       {
          do
          {
               playerRow = SafeInput.getRangedInt(sc, "Player X, which row? (1 - 3): ", 1, 3);
               playerCol = SafeInput.getRangedInt(sc, "Player X, which col? (1 - 3): ", 1, 3);
               
               if(isValidMove(playerRow - 1, playerCol - 1))
               {
                   player = "X";
                   board[playerRow-1][playerCol-1]=player;
                   showBoard();
                   moves += 1;
               }
               else
               {
                   System.out.println("Invalid move, spot is already played");
                   break;
               }
               
               if(isRowWin(player) || isColWin(player) || isDiagonalWin(player))
               {
                   System.out.println("Player " + player + " wins!");
                   System.out.println("");
                   
                   if(!SafeInput.getYNConfirm(sc, "Play again?: "))
                   {
                       play = false;
                       break;
                   }
                   
                   else
                   {
                       clearBoard();
                       sc.nextLine();
                       moves = 0;
                       break;
                   }
                   
               }
               
               if(moves == 9)
                   {
                       System.out.println("It's a draw!");
                   
                       if(!SafeInput.getYNConfirm(sc, "Play again?: "))
                       {
                            play = false;
                       }
                       else
                       {
                           clearBoard();
                           sc.nextLine();
                           moves = 0;
                           break;
                       }
                   }
               
               do  
               {
                      
                playerRow = SafeInput.getRangedInt(sc, "Player O, which row? (1 - 3): ", 1, 3);
                playerCol = SafeInput.getRangedInt(sc, "Player O, which col? (1 - 3): ", 1, 3);
    
                
                if(isValidMove(playerRow - 1, playerCol - 1))
                   {
                    player = "O";
                    board[playerRow-1][playerCol-1]=player;
                    showBoard();
                    moves += 1;
                    valid = true;
                   }
                   else
                   {
                    System.out.println("Invalid move, spot is already played");
                    valid = false;
                   }
               }while(!valid);
               
               if(isRowWin(player) || isColWin(player) || isDiagonalWin(player))
               {
                   System.out.println("Player " + player + " wins!");
                   System.out.println("");
                   
                   if(!SafeInput.getYNConfirm(sc, "Play again?: "))
                   {
                       play = false;
                       break;
                   }
                   
                   else
                   {
                       clearBoard();
                       sc.nextLine();
                       moves = 0;
                       break;
                   }
                   
               }
               
               if(moves == 9)
                   {
                       System.out.println("It's a draw!");
                   
                       if(!SafeInput.getYNConfirm(sc, "Play again?: "))
                       {
                            play = false;
                       }
                       else
                       {
                           clearBoard();
                           sc.nextLine();
                           moves = 0;
                           break;
                       }
                   }
               
          }while(play);
          
       }while(play);
     
    }
    
    
    private static void clearBoard()
    {
        for(int row=0; row<ROW; row++)
        {
            for(int col=0; col<COL; col++)
            {
                board[row][col] = " ";
            }
        }
    }
    
    private static void showBoard()
    {
        for(int row=0; row<ROW; row++)
        {
            for(int col=0; col<COL; col++)
            {
                if(col == 2 )
                {
                    System.out.print(board[row][col]);
                }
                else
                {
                    System.out.print(board[row][col] + " | ");
                }
                
            }
            
            System.out.println("");
            
            if(row != 2)
            {
                System.out.println("----------");
            }
            
        }
        
        System.out.println("");
    }
    
    private static boolean isValidMove(int row, int col)
    {
        
        boolean isValid = false;
        
        if(board[row][col].equals(" "))
            isValid = true;
        
        return isValid;
    }
    
    private static boolean isRowWin(String player)
    {
        for(int row=0; row<ROW; row++)
        {
            if(board[row][0].equals(player) && board[row][1].equals(player) && board[row][2].equals(player))
            {
                return true;
            }
        }
        
        return false;
    }
    
    private static boolean isColWin(String player)
    {
        for(int col=0; col<COL; col++)
        {
            if(board[0][col].equals(player) && board[1][col].equals(player) && board[2][col].equals(player))
            {
                return true;
            }
        }
        
        return false;
    }
    
    private static boolean isDiagonalWin(String player)
    {
        if(board[0][0].equals(player) && board[1][1].equals(player) && board[2][2].equals(player))
        {
            return true;
        }
        else if(board[2][0].equals(player) && board[1][1].equals(player) && board[0][2].equals(player))
        {
            return true;
        }
        
        return false;
    }

}
