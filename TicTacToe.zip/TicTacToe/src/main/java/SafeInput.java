
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 *
 * @author zharr
 */
public class SafeInput 
{
   
   public static String getNonZeroLenString(Scanner pipe, String prompt)
   {
       String retString = "";
       do
       {
           System.out.println("\n" +prompt + ": ");
           retString = pipe.nextLine();
       }while(retString.length() == 0);
       
       return retString;
       
   }
   
   public static int getInt(Scanner pipe, String prompt)
   {
       int num = 0;
       String input;
              
       System.out.println(prompt);
       
       while(pipe.hasNext())
       {       
           input = pipe.nextLine();
           try
           {
               num = Integer.parseInt(input);
               break;
           } catch (NumberFormatException e) {
               System.out.println("Invalid input received.  Enter a valid integer: ");
           }
       }
       
       return num;
       
   }
   
   public static double getDouble(Scanner pipe, String prompt)
   {
       double num = 0;
       String input;
              
       System.out.println(prompt);
       
       while(pipe.hasNext())
       {       
           input = pipe.nextLine();
           try
           {
               num = Double.parseDouble(input);
               break;
           } catch (NumberFormatException e) {
               System.out.println("Invalid input received.  Enter a valid double: ");
           }
       }
       
       return num;

   }
   
   public static int getRangedInt(Scanner pipe, String prompt, int low, int high)
   {
       int num = 0;
       boolean go = false;
       
       System.out.println(prompt);
       
       while(!go)
       {
           try
           {
                num = Integer.parseInt(pipe.nextLine());
        
                if(num < low || num > high)
                {
                    System.out.println("Selection is out of range.  Must enter a valid integer between " + low + " and " + high);
                }
                else
                {
                    go = true;
                }
           }catch(NumberFormatException e) {
               System.out.println("Invalid input received.  Enter a valid integer between " + low + " and " + high);
           }
           
       }
       
       return num;
       
   }
   
   public static double getRangedDouble(Scanner pipe, String prompt, double low, double high)
   {
       double num = 0;
       boolean go = false;
       String input;
       
       System.out.println(prompt);
       
       while(!go)
       {
           input = pipe.nextLine();
           try
           {
                num = Double.parseDouble(input);
        
                if(num < low || num > high)
                {
                    System.out.println("Selection is out of range.  Must enter a valid double between " + low + " and " + high + ": ");
                }
                else
                {
                    go = true;
                }
           }catch(NumberFormatException e) {
               System.out.println("Invalid input received.  Enter a valid double between " + low + " and " + high + ": ");
           }
           
       }
       
       return num;

   }
   
   public static boolean getYNConfirm(Scanner pipe, String prompt)
   {
       System.out.println(prompt);
       boolean isValid = false;
       boolean input = true;
       String response;
       
       do
       {
           response = pipe.next();
           
           switch(response) {
               case "y":
                   isValid = true;
                   input = true;
                   break;
               case "Y":
                   isValid = true;
                   input = true;
                   break;
               case "n":
                   isValid = false;
                   input = true;
                   break;
               case "N":
                   isValid = false;
                   input = true;
                   break;
               default:
                   input = false;
                   System.out.println("Invalid input received. Must be Y or N: ");
                   break;
           }
           
       }while(!input);
       
       return isValid;
   }
   
   public static String getRegExString(Scanner pipe, String prompt, String regEx)
   {
       System.out.println(prompt);
       boolean input = true;
       String response;
       
       do
       {
            response = pipe.nextLine();
            
            Pattern pattern = Pattern.compile(regEx);
            
            Matcher matcher = pattern.matcher(response);
            
            if(matcher.find()) {
               break;
            }else {
               System.out.println("Format must match " + regEx);
               input = false;
            }

       }while(!input);
       
       return response;
   }
   
   public static void prettyHeader(String msg)
   {
      
        for(int i = 0; i <= 60; i++)
        {
            System.out.print("*");
        }
        
        System.out.println("");
        
        for(int r = 0; r < 3; r++)
        {
            System.out.print("*");
        }
        
        for(int i = 0; i <= (54 - msg.length())/2; i++)
        {
            System.out.print(" ");
        }
        
        System.out.print(msg);
        
        if(msg.length()%2 != 0)
        {
            for(int i = 0; i <= (54 - msg.length())/2; i++)
            {
                System.out.print(" ");
            }
        }
        else
        {
            for(int i = 0; i <= (54 - msg.length())/2-1; i++)
            {
                System.out.print(" ");
            }

        }
        
        for(int r = 0; r < 3; r++)
        {
            System.out.print("*");
        }
        
        System.out.println("");
        
        for(int i = 0; i <= 60; i++)
        {
            System.out.print("*");
        }
 
   }
     
}
